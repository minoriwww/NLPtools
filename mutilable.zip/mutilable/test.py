# # -*- coding:utf8 -*- 
# import re
# lables = [
# "农业",

# "工业",

# "交通邮电",

# "商业贸易",

# "财政",

# "固定资产投资", 

# "省际物资购销",

# "公共卫生", 
# "文化事业",

# "国民经济",
# "金融",
# "历史回顾",
# "方针思想",
# "人才培育",
# "法制建设",
# "环境保护",
# "产业结构",
# "海外投资",
# "企业改革",
# "土地改革",
# "服务业",
# "私营经济",
# "科技研究"
# ]

# str_ch = '科技研究 阿萨 德'
# # temp = re.split(r'(\s+)',str_ch)
# temp = str_ch.split(" ")
# print str_ch.split(" ")[0].decode('utf-8')
# if temp[0] in lables:
# 	print "ok"
# print ",".join(temp).decode('utf-8')

